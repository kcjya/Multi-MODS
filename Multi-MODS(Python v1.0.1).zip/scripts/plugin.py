

class Parse:
    def __init__(self):
        pass
    def parse(self):
        pass
    def render(self):
        pass

def getPluginClass():
    return Parse

